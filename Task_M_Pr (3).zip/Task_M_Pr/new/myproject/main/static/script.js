let tasks = [];

const addTask = (event) => {
    event.preventDefault(); // Prevent form submission reload
    const taskInput = document.querySelector("input");
    const text = taskInput.value.trim();

    if (text) {
        tasks.push({ text: text, completed: false });
        taskInput.value = "";
        updateTasksList();
    }
};

const updateTasksList = () => {
    const taskList = document.querySelector(".task-list");
    taskList.innerHTML = ""; // Clear previous list

    tasks.forEach((task, index) => {
        const listItem = document.createElement("li");
        listItem.classList.add("taskItem");

        listItem.innerHTML = `
            <div class="task">
                <input type="checkbox" class="checkbox" ${task.completed ? "checked" : ""} onclick="toggleTask(${index})"/>
                <p class="${task.completed ? 'completed' : ''}">${task.text}</p>
            </div>
            <div class="icons">
                <button onclick="editTask(${index})">✏️</button>
                <button onclick="deleteTask(${index})">❌</button>
                <button class="complete-btn" onclick="markCompleted(${index})">✅</button>
                <button onclick="setTimer(${index})">⏳</button>
            </div>
        `;

        taskList.appendChild(listItem);
    });

    updateProgress();
};

const toggleTask = (index) => {
    tasks[index].completed = !tasks[index].completed;
    updateTasksList();
};

const editTask = (index) => {
    const newText = prompt("Edit your task:", tasks[index].text);
    if (newText !== null && newText.trim() !== "") {
        tasks[index].text = newText.trim();
        updateTasksList();
    }
};

const deleteTask = (index) => {
    tasks.splice(index, 1);
    updateTasksList();
};

const markCompleted = (index) => {
    tasks[index].completed = true;
    updateTasksList();
};

const setTimer = (index) => {
    const minutes = prompt("Set timer (in minutes):");
    if (minutes && !isNaN(minutes) && minutes > 0) {
        let timeLeft = minutes * 60;
        
        const countdown = setInterval(() => {
            if (timeLeft <= 0) {
                clearInterval(countdown);
                alert(`Time's up for: ${tasks[index].text}`);
            }
            timeLeft--;
        }, 1000);
    }
};

const updateProgress = () => {
    const completedTasks = tasks.filter(task => task.completed).length;
    const totalTasks = tasks.length;
    const progressPercentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

    document.getElementById("progress").style.width = `${progressPercentage}%`;
    document.getElementById("numbers").textContent = `${completedTasks} / ${totalTasks}`;
};

document.querySelector("form").addEventListener("submit", addTask);
