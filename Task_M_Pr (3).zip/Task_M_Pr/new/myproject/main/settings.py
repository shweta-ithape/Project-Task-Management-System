INSTALLED_APPS = [
    'main',
    'django.contrib.admin',
    ...
]

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / "main/templates"],
        ...
    },
]
