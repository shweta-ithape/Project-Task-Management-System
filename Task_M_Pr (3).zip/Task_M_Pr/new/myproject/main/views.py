from django.shortcuts import render
import requests

def home(request):
    return render(request, "home.html")

def index(request):
    return render(request, "index.html")

def news(request):
    api_key = "YOUR_NEWSAPI_KEY"
    url = f"https://newsapi.org/v2/top-headlines?country=us&apiKey={api_key}"
    response = requests.get(url).json()
    articles = response.get("articles", [])
    return render(request, "news.html", {"articles": articles})
